/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2012 James Chen
 Copyright (c) 2013-2015 zilongshanren
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 Copyright (c) 2019-present Simdsoft Limited.

 https://axmol.dev/

 SPDX-License-Identifier: MIT
 ****************************************************************************/
#include "axmol/ui/EditBox/EditBoxImpl-ios.h"

#if (AX_TARGET_PLATFORM == AX_PLATFORM_IOS)

#    define kLabelZOrder 9999

#    include "axmol/ui/EditBox/EditBox.h"
#    include "axmol/base/Director.h"
#    include "axmol/2d/Label.h"
#    import "axmol/platform/ios/RenderHostView-ios.h"

#    import <Foundation/Foundation.h>
#    import <UIKit/UIKit.h>

#    import "axmol/ui/EditBox/iOS/EditBoxIOS.h"

#    define getEditBoxImplIOS() ((ax::ui::EditBoxImplIOS*)_editBox)

namespace ax
{

namespace ui
{

EditBoxImpl* __createSystemEditBox(EditBox* pEditBox)
{
    return new EditBoxImplIOS(pEditBox);
}

EditBoxImplIOS::EditBoxImplIOS(EditBox* pEditText) : EditBoxImplCommon(pEditText), _systemControl(nullptr) {}

EditBoxImplIOS::~EditBoxImplIOS()
{
    _systemControl = nil;
}

void EditBoxImplIOS::createNativeControl()
{
    _systemControl = [[UIEditBoxImplIOS_objc alloc] initWithFrame:CGRectMake(0, 0, 1, 1) editBox:this];
}

bool EditBoxImplIOS::isEditing()
{
    return [_systemControl isEditState] ? true : false;
}

void EditBoxImplIOS::doAnimationWhenKeyboardMove(float duration, float distance)
{
    if ([_systemControl isEditState] || distance < 0.0f)
    {
        [_systemControl doAnimationWhenKeyboardMoveWithDuration:duration distance:distance];
    }
}

void EditBoxImplIOS::setNativeFont(std::string_view fontName, int fontSize)
{
    UIFont* textFont = createNativeFont(fontName, fontSize);
    if (textFont != nil)
    {
        [_systemControl setFont:textFont];
    }
}

void EditBoxImplIOS::setNativeFontColor(const Color32& color)
{
    _systemControl.textColor = [UIColor colorWithRed:color.r / 255.0f
                                               green:color.g / 255.0f
                                                blue:color.b / 255.0f
                                               alpha:color.a / 255.f];
}

void EditBoxImplIOS::setNativePlaceholderFont(std::string_view fontName, int fontSize)
{
    UIFont* textFont = createNativeFont(fontName, fontSize);
    if (textFont != nil)
    {
        [_systemControl setPlaceholderFont:textFont];
    }
}

void EditBoxImplIOS::setNativePlaceholderFontColor(const Color32& color)
{
    [_systemControl setPlaceholderTextColor:[UIColor colorWithRed:color.r / 255.0f
                                                            green:color.g / 255.0f
                                                             blue:color.b / 255.0f
                                                            alpha:color.a / 255.f]];
}

void EditBoxImplIOS::setNativeInputMode(EditBox::InputMode inputMode)
{
    [_systemControl setInputMode:inputMode];

    auto oldPos = _editBox->getPosition();
    _editBox->setPosition(oldPos + Vec2(10, 10));
    _editBox->setPosition(oldPos);
}

void EditBoxImplIOS::setNativeInputFlag(EditBox::InputFlag inputFlag)
{
    [_systemControl setInputFlag:inputFlag];
}

NSString* removeSiriString(NSString* str)
{
    NSString* siriString = @"\xef\xbf\xbc";
    return [str stringByReplacingOccurrencesOfString:siriString withString:@""];
}

std::string_view EditBoxImplIOS::getText()
{
    return [removeSiriString(_systemControl.text) UTF8String];
}

void EditBoxImplIOS::setNativeReturnType(EditBox::KeyboardReturnType returnType)
{
    [_systemControl setReturnType:returnType];
}

void EditBoxImplIOS::setNativeTextHorizontalAlignment(ax::TextHAlignment alignment)
{
    [_systemControl setTextHorizontalAlignment:alignment];
}

void EditBoxImplIOS::setNativeTextVerticalAlignment(ax::TextVAlignment alignment)
{
    [_systemControl setTextVerticalAlignment:alignment];
}

void EditBoxImplIOS::setNativeText(std::string_view text)
{
    NSString* nsText = [[NSString alloc] initWithBytes:text.data() length:text.length() encoding:NSUTF8StringEncoding];
    if ([nsText compare:_systemControl.text] != NSOrderedSame)
    {
        _systemControl.text = nsText;
    }
}

void EditBoxImplIOS::setNativePlaceHolder(std::string_view text)
{
    NSString* nsText = [[NSString alloc] initWithBytes:text.data() length:text.length() encoding:NSUTF8StringEncoding];
    [_systemControl setPlaceHolder:nsText];
}

void EditBoxImplIOS::setNativeVisible(bool visible)
{
    [_systemControl setVisible:visible];
}

void EditBoxImplIOS::updateNativeFrame(const Rect& rect)
{
    auto renderView = ax::Director::getInstance()->getRenderView();
    auto hostView   = (__bridge RenderHostView*)renderView->getNativeDisplay().ptr;

    float factor = 1.0f;  // hostView.contentScaleFactor;

    [_systemControl updateFrame:CGRectMake(rect.origin.x / factor, rect.origin.y / factor, rect.size.width / factor,
                                           rect.size.height / factor)];
}

std::string_view EditBoxImplIOS::getNativeDefaultFontName()
{
    return [[_systemControl getDefaultFontName] UTF8String];
}

void EditBoxImplIOS::nativeOpenKeyboard()
{
    [_systemControl setVisible:YES];
    [_systemControl openKeyboard];
}

void EditBoxImplIOS::nativeCloseKeyboard()
{
    [_systemControl closeKeyboard];
}

UIFont* EditBoxImplIOS::createNativeFont(std::string_view fontName, int fontSize)
{
    AXASSERT(!fontName.empty(), "fontName can't be nullptr");
    auto hostView      = (__bridge RenderHostView*)ax::Director::getInstance()->getRenderView()->getNativeDisplay().ptr;
    float retinaFactor = hostView.contentScaleFactor;
    NSString* fntName  = [[NSString alloc] initWithBytes:fontName.data()
                                                 length:fontName.length()
                                               encoding:NSUTF8StringEncoding];
    auto renderView    = ax::Director::getInstance()->getRenderView();
    float scaleFactor  = renderView->getScaleX();

    if (fontSize == -1)
    {
        fontSize = _systemControl.frameRect.size.height * 2 / 3;
    }
    else
    {
        fontSize = fontSize * scaleFactor / renderView->getRenderScale();
    }

    UIFont* textFont = [UIFont fontWithName:fntName size:fontSize];
    if (textFont == nil)
    {
        textFont = [UIFont systemFontOfSize:fontSize];
    }
    return textFont;
}
}  // namespace ui

}  // namespace ax

#endif /* #if (AX_TARGET_PLATFORM == AX_PLATFORM_IOS) */
