/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2012 James Chen
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 Copyright (c) 2019-present Simdsoft Limited.

 https://axmol.dev/

 SPDX-License-Identifier: MIT
 ****************************************************************************/

#include "axmol/ui/EditBox/EditBox.h"
#include "axmol/ui/EditBox/EditBoxImpl-common.h"
#include "axmol/ui/UIHelper.h"

namespace ax
{

namespace ui
{

static const int NORMAL_RENDERER_Z   = (-2);
static const int PRESSED_RENDERER_Z  = (-2);
static const int DISABLED_RENDERER_Z = (-2);

static const float CHECK_EDITBOX_POLL_EVENTS_INTERVAL = 0.1f;

EditBox::EditBox()
    : _normalTextureSize(_contentSize), _pressedTextureSize(_contentSize), _disabledTextureSize(_contentSize)
{}

EditBox::~EditBox()
{
    if (_windowResizeListener)
    {
        _eventDispatcher->removeEventListener(_windowResizeListener);
        AX_SAFE_RELEASE_NULL(_windowResizeListener);
    }

    AX_SAFE_DELETE(_editBoxImpl);
#if AX_ENABLE_SCRIPT_BINDING
    unregisterScriptEditBoxHandler();
#endif
}

void EditBox::openKeyboard() const
{
    _editBoxImpl->openKeyboard();
}

void EditBox::closeKeyboard() const
{
    _editBoxImpl->closeKeyboard();
}

EditBox* EditBox::create(const Vec2& size, std::string_view normalImage, TextureResType texType)
{
    return EditBox::create(size, normalImage, "", "", texType);
}

EditBox* EditBox::create(const Vec2& size,
                         std::string_view normalImage,
                         std::string_view pressedImage /* = "" */,
                         std::string_view disabledImage /* = "" */,
                         TextureResType texType /* = TextureResType::LOCAL */)
{
    EditBox* pRet = new EditBox();
    if (pRet->initWithSizeAndTexture(size, normalImage, pressedImage, disabledImage, texType))
    {
        pRet->autorelease();
    }
    else
    {
        AX_SAFE_DELETE(pRet);
    }

    return pRet;
}

EditBox* EditBox::create(const Vec2& size,
                         ax::ui::Scale9Sprite* normalSprite,
                         ui::Scale9Sprite* pressedSprite,
                         Scale9Sprite* disabledSprite)
{
    EditBox* pRet = new EditBox();
    if (pRet->initWithSizeAndBackgroundSprite(size, normalSprite, pressedSprite, disabledSprite))
    {
        pRet->autorelease();
    }
    else
    {
        AX_SAFE_DELETE(pRet);
    }
    return pRet;
}

bool EditBox::initWithSizeAndBackgroundSprite(const Vec2& size, Scale9Sprite* normal9SpriteBg)
{
    return initWithSizeAndBackgroundSprite(size, normal9SpriteBg, nullptr, nullptr);
}

bool EditBox::initWithSizeAndBackgroundSprite(const Vec2& size,
                                              Scale9Sprite* normalSprite,
                                              Scale9Sprite* pressedSprite,
                                              Scale9Sprite* disabledSprite)
{
    if (Widget::init())
    {
        _editBoxImpl = __createSystemEditBox(this);
        _editBoxImpl->initWithSize(size);
        _editBoxImpl->setInputMode(EditBox::InputMode::ANY);

        loadTextureNormal(normalSprite->getResourceName(),
                          normalSprite->getResourceType() == 0 ? TextureResType::LOCAL : TextureResType::PLIST);
        if (pressedSprite != nullptr)
        {
            loadTexturePressed(pressedSprite->getResourceName(),
                               pressedSprite->getResourceType() == 0 ? TextureResType::LOCAL : TextureResType::PLIST);
        }
        if (disabledSprite != nullptr)
        {
            loadTexturePressed(disabledSprite->getResourceName(),
                               disabledSprite->getResourceType() == 0 ? TextureResType::LOCAL : TextureResType::PLIST);
        }

        this->setContentSize(size);

        this->setPointerEnabled(true);

        return true;
    }
    return false;
}

bool EditBox::initWithSizeAndBackgroundSprite(const Vec2& size,
                                              std::string_view pNormal9SpriteBg,
                                              TextureResType texType)
{
    return initWithSizeAndTexture(size, pNormal9SpriteBg, "", "", texType);
}

bool EditBox::initWithSizeAndTexture(const Vec2& size,
                                     std::string_view normalImage,
                                     std::string_view pressedImage /* = "" */,
                                     std::string_view disabledImage /* = "" */,
                                     TextureResType texType /* = TextureResType::LOCAL */)
{
    if (Widget::init())
    {
        _editBoxImpl = __createSystemEditBox(this);
        _editBoxImpl->initWithSize(size);
        _editBoxImpl->setInputMode(EditBox::InputMode::ANY);

        loadTextures(normalImage, pressedImage, disabledImage, texType);

        this->setContentSize(size);
        this->setPointerEnabled(true);

        return true;
    }
    return false;
}

void EditBox::initRenderNode()
{
    _normalRenderer   = Scale9Sprite::create();
    _pressedRenderer  = Scale9Sprite::create();
    _disabledRenderer = Scale9Sprite::create();
    _normalRenderer->setRenderingType(Scale9Sprite::RenderingType::SLICE);
    _pressedRenderer->setRenderingType(Scale9Sprite::RenderingType::SLICE);
    _disabledRenderer->setRenderingType(Scale9Sprite::RenderingType::SLICE);

    addProtectedChild(_normalRenderer, NORMAL_RENDERER_Z, -1);
    addProtectedChild(_pressedRenderer, PRESSED_RENDERER_Z, -1);
    addProtectedChild(_disabledRenderer, DISABLED_RENDERER_Z, -1);
}

void EditBox::loadTextures(std::string_view normal,
                           std::string_view pressed,
                           std::string_view disabled,
                           TextureResType texType)
{
    loadTextureNormal(normal, texType);
    loadTexturePressed(pressed, texType);
    loadTextureDisabled(disabled, texType);
}

void EditBox::loadTextureNormal(std::string_view normal, TextureResType texType)
{
    _normalFileName    = normal;
    _normalTexType     = texType;
    bool textureLoaded = true;
    if (normal.empty())
    {
        _normalRenderer->resetRender();
        textureLoaded = false;
    }
    else
    {
        switch (texType)
        {
        case TextureResType::LOCAL:
            _normalRenderer->initWithFile(normal);
            break;
        case TextureResType::PLIST:
            _normalRenderer->initWithSpriteFrameName(normal);
            break;
        default:
            break;
        }
    }
    // FIXME: https://github.com/cocos2d/cocos2d-x/issues/12249
    if (!_autoSize && _customSize.equals(Vec2::zero))
    {
        _customSize = _normalRenderer->getContentSize();
    }
    this->setupNormalTexture(textureLoaded);
}

void EditBox::setupNormalTexture(bool textureLoaded)
{
    _normalTextureSize = _normalRenderer->getContentSize();

    this->updateChildrenDisplayedRGBA();

    _normalTextureLoaded     = textureLoaded;
    _normalTextureAdaptDirty = true;
}

void EditBox::loadTextureNormal(SpriteFrame* normalSpriteFrame)
{
    _normalRenderer->initWithSpriteFrame(normalSpriteFrame);
    this->setupNormalTexture(nullptr != normalSpriteFrame);
}

void EditBox::loadTexturePressed(std::string_view pressed, TextureResType texType)
{
    _pressedFileName   = pressed;
    _pressedTexType    = texType;
    bool textureLoaded = true;
    if (pressed.empty())
    {
        _pressedRenderer->resetRender();
        textureLoaded = false;
    }
    else
    {
        switch (texType)
        {
        case TextureResType::LOCAL:
            _pressedRenderer->initWithFile(pressed);
            break;
        case TextureResType::PLIST:
            _pressedRenderer->initWithSpriteFrameName(pressed);
            break;
        default:
            break;
        }
    }
    this->setupPressedTexture(textureLoaded);
}

void EditBox::setupPressedTexture(bool textureLoaded)
{
    _pressedTextureSize = _pressedRenderer->getContentSize();

    this->updateChildrenDisplayedRGBA();

    _pressedTextureLoaded     = textureLoaded;
    _pressedTextureAdaptDirty = true;
}

void EditBox::loadTexturePressed(SpriteFrame* pressedSpriteFrame)
{
    _pressedRenderer->initWithSpriteFrame(pressedSpriteFrame);
    this->setupPressedTexture(nullptr != pressedSpriteFrame);
}

void EditBox::loadTextureDisabled(std::string_view disabled, TextureResType texType)
{
    _disabledFileName  = disabled;
    _disabledTexType   = texType;
    bool textureLoaded = true;
    if (disabled.empty())
    {
        _disabledRenderer->resetRender();
        textureLoaded = false;
    }
    else
    {
        switch (texType)
        {
        case TextureResType::LOCAL:
            _disabledRenderer->initWithFile(disabled);
            break;
        case TextureResType::PLIST:
            _disabledRenderer->initWithSpriteFrameName(disabled);
            break;
        default:
            break;
        }
    }
    this->setupDisabledTexture(textureLoaded);
}

void EditBox::setupDisabledTexture(bool textureLoaded)
{
    _disabledTextureSize = _disabledRenderer->getContentSize();

    this->updateChildrenDisplayedRGBA();

    _disabledTextureLoaded     = textureLoaded;
    _disabledTextureAdaptDirty = true;
}

void EditBox::loadTextureDisabled(SpriteFrame* disabledSpriteFrame)
{
    _disabledRenderer->initWithSpriteFrame(disabledSpriteFrame);
    this->setupDisabledTexture(nullptr != disabledSpriteFrame);
}

void EditBox::setCapInsets(const Rect& capInsets)
{
    setCapInsetsNormalRenderer(capInsets);
    setCapInsetsPressedRenderer(capInsets);
    setCapInsetsDisabledRenderer(capInsets);
}

void EditBox::setCapInsetsNormalRenderer(const Rect& capInsets)
{
    _capInsetsNormal = Helper::restrictCapInsetRect(capInsets, this->_normalTextureSize);
    _normalRenderer->setCapInsets(_capInsetsNormal);
}

void EditBox::setCapInsetsPressedRenderer(const Rect& capInsets)
{
    _capInsetsPressed = Helper::restrictCapInsetRect(capInsets, this->_pressedTextureSize);
    _pressedRenderer->setCapInsets(_capInsetsPressed);
}

void EditBox::setCapInsetsDisabledRenderer(const Rect& capInsets)
{
    _capInsetsDisabled = Helper::restrictCapInsetRect(capInsets, this->_disabledTextureSize);
    _disabledRenderer->setCapInsets(_capInsetsDisabled);
}

const Rect& EditBox::getCapInsetsNormalRenderer() const
{
    return _capInsetsNormal;
}

const Rect& EditBox::getCapInsetsPressedRenderer() const
{
    return _capInsetsPressed;
}

const Rect& EditBox::getCapInsetsDisabledRenderer() const
{
    return _capInsetsDisabled;
}

void EditBox::onPressStateChangedToNormal()
{
    _normalRenderer->setVisible(true);
    _pressedRenderer->setVisible(false);
    _disabledRenderer->setVisible(false);
    _normalRenderer->setState(Scale9Sprite::State::NORMAL);
}

void EditBox::onPressStateChangedToPressed()
{
    _normalRenderer->setState(Scale9Sprite::State::NORMAL);

    if (_pressedTextureLoaded)
    {
        _normalRenderer->setVisible(false);
        _pressedRenderer->setVisible(true);
        _disabledRenderer->setVisible(false);
    }
    else
    {
        _normalRenderer->setVisible(true);
        _pressedRenderer->setVisible(true);
        _disabledRenderer->setVisible(false);
    }
}

void EditBox::onPressStateChangedToDisabled()
{
    // if disabled resource is null
    if (!_disabledTextureLoaded)
    {
        if (_normalTextureLoaded)
        {
            _normalRenderer->setState(Scale9Sprite::State::GRAY);
        }
    }
    else
    {
        _normalRenderer->setVisible(false);
        _disabledRenderer->setVisible(true);
    }

    _pressedRenderer->setVisible(false);
}

void EditBox::releaseUpEvent()
{
    Widget::releaseUpEvent();
    openKeyboard();
}

void EditBox::setDelegate(EditBoxDelegate* pDelegate)
{
    _delegate = pDelegate;
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setDelegate(pDelegate);
    }
}

EditBoxDelegate* EditBox::getDelegate()
{
    return _delegate;
}

void EditBox::setText(std::string_view text)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setText(text);
    }
}

std::string_view EditBox::getText() const
{
    if (_editBoxImpl != nullptr)
    {
        std::string_view text = _editBoxImpl->getText();
        if (!text.empty())
            return text;
    }

    return ""sv;
}

void EditBox::setFont(std::string_view fontName, int fontSize)
{
    AXASSERT(!fontName.empty(), "fontName can't be empty");
    if (!fontName.empty())
    {
        if (_editBoxImpl != nullptr)
        {
            _editBoxImpl->setFont(fontName, fontSize);
        }
    }
}

void EditBox::setFontName(std::string_view fontName)
{
    AXASSERT(!fontName.empty(), "fontName can't be empty");
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setFont(fontName, _editBoxImpl->getFontSize());
    }
}

std::string_view EditBox::getFontName() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getFontName();
    }
    return ""sv;
}

void EditBox::setFontSize(int fontSize)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setFont(_editBoxImpl->getFontName(), fontSize);
    }
}

int EditBox::getFontSize() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getFontSize();
    }
    return -1;
}

void EditBox::setFontColor(const Color32& color)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setFontColor(color);
    }
}

const Color32& EditBox::getFontColor() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getFontColor();
    }
    return Color32::white;
}

void EditBox::setPlaceholderFont(std::string_view fontName, int fontSize)
{
    AXASSERT(!fontName.empty(), "fontName can't be empty");
    if (!fontName.empty())
    {
        if (_editBoxImpl != nullptr)
        {
            _editBoxImpl->setPlaceholderFont(fontName, fontSize);
        }
    }
}

void EditBox::setPlaceholderFontName(std::string_view fontName)
{
    AXASSERT(!fontName.empty(), "fontName can't be empty");
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setPlaceholderFont(fontName, _editBoxImpl->getPlaceholderFontSize());
    }
}

std::string_view EditBox::getPlaceholderFontName() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getPlaceholderFontName();
    }
    return "";
}

void EditBox::setPlaceholderFontSize(int fontSize)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setPlaceholderFont(_editBoxImpl->getPlaceholderFontName(), fontSize);
    }
}

int EditBox::getPlaceholderFontSize() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getPlaceholderFontSize();
    }
    return -1;
}

void EditBox::setPlaceholderFontColor(const Color32& color)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setPlaceholderFontColor(color);
    }
}

const Color32& EditBox::getPlaceholderFontColor() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getPlaceholderFontColor();
    }
    return Color32::gray;
}

void EditBox::setPlaceHolder(std::string_view text)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setPlaceHolder(text);
    }
}

std::string_view EditBox::getPlaceHolder() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getPlaceHolder();
    }
    return ""sv;
}

void EditBox::setInputMode(EditBox::InputMode inputMode)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setInputMode(inputMode);
    }
}

EditBox::InputMode EditBox::getInputMode() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getInputMode();
    }
    return InputMode::SINGLE_LINE;
}

void EditBox::setMaxLength(int maxLength)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setMaxLength(maxLength);
    }
}

int EditBox::getMaxLength()
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getMaxLength();
    }
    return -1;
}

void EditBox::setInputFlag(EditBox::InputFlag inputFlag)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setInputFlag(inputFlag);
    }
}

EditBox::InputFlag EditBox::getInputFlag() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getInputFlag();
    }
    return InputFlag::LOWERCASE_ALL_CHARACTERS;
}

void EditBox::setReturnType(EditBox::KeyboardReturnType returnType)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setReturnType(returnType);
    }
}

EditBox::KeyboardReturnType EditBox::getReturnType() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getReturnType();
    }
    return KeyboardReturnType::DEFAULT;
}

void EditBox::setTextHorizontalAlignment(TextHAlignment alignment)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setTextHorizontalAlignment(alignment);
    }
}

TextHAlignment EditBox::getTextHorizontalAlignment() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getTextHorizontalAlignment();
    }
    return TextHAlignment::LEFT;
}

void EditBox::setTextVerticalAlignment(TextVAlignment alignment)
{
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setTextVerticalAlignment(alignment);
    }
}

TextVAlignment EditBox::getTextVerticalAlignment() const
{
    if (_editBoxImpl != nullptr)
    {
        return _editBoxImpl->getTextVerticalAlignment();
    }
    return TextVAlignment::CENTER;
}

/* override function */
void EditBox::setPosition(const Vec2& pos)
{
    Widget::setPosition(pos);
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setPosition(pos);
    }
}

void EditBox::setVisible(bool visible)
{
    Widget::setVisible(visible);
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setVisible(visible);
    }
}

void EditBox::setContentSize(const Vec2& size)
{
    Widget::setContentSize(size);
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setContentSize(size);
    }
}

void EditBox::onSizeChanged()
{
    Widget::onSizeChanged();
    _normalTextureAdaptDirty   = true;
    _pressedTextureAdaptDirty  = true;
    _disabledTextureAdaptDirty = true;
}

void EditBox::updateLayout()
{
    if (_normalTextureAdaptDirty)
    {
        normalTextureScaleChangedWithSize();
        _normalTextureAdaptDirty = false;
    }

    if (_pressedTextureAdaptDirty)
    {
        pressedTextureScaleChangedWithSize();
        _pressedTextureAdaptDirty = false;
    }

    if (_disabledTextureAdaptDirty)
    {
        disabledTextureScaleChangedWithSize();
        _disabledTextureAdaptDirty = false;
    }
}

void EditBox::normalTextureScaleChangedWithSize()
{
    _normalRenderer->setContentSize(_contentSize);
    _normalRenderer->setPosition(_contentSize.width / 2.0f, _contentSize.height / 2.0f);
}

void EditBox::pressedTextureScaleChangedWithSize()
{
    _pressedRenderer->setContentSize(_contentSize);
    _pressedRenderer->setPosition(_contentSize.width / 2.0f, _contentSize.height / 2.0f);
}

void EditBox::disabledTextureScaleChangedWithSize()
{
    _disabledRenderer->setContentSize(_contentSize);
    _disabledRenderer->setPosition(_contentSize.width / 2.0f, _contentSize.height / 2.0f);
}

void EditBox::setAnchorPoint(const Vec2& anchorPoint)
{
    Widget::setAnchorPoint(anchorPoint);
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->setAnchorPoint(anchorPoint);
    }
}

std::string EditBox::getDescription() const
{
    return "EditBox";
}

void EditBox::draw(const SceneRenderState& state, const Mat4& parentTransform, uint32_t parentFlags)
{
    Widget::draw(state, parentTransform, parentFlags);
    if (_editBoxImpl)
    {
        _editBoxImpl->draw(state, parentTransform, parentFlags & FLAGS_TRANSFORM_DIRTY);
    }
}

void EditBox::onEnter()
{
    Widget::onEnter();
    if (_editBoxImpl)
    {
        _editBoxImpl->onEnter();
    }
#if (AX_TARGET_PLATFORM == AX_PLATFORM_LINUX)
    if (Director::getInstance()->getRenderView()->getWindowPlatform() == WindowPlatform::X11)
        this->schedule(AX_SCHEDULE_SELECTOR(EditBox::pollEvents), 0);
#endif

#ifdef AX_PLATFORM_PC
    if (!_windowResizeListener)
    {
        _windowResizeListener = _director->getEventDispatcher()->addCustomEventListener(
            RenderView::EVENT_WINDOW_RESIZED, [this](CustomEvent*) {
            if (_editBoxImpl)
            {
                auto rect = ui::Helper::getNodeNativeWindowRect(this);
                static_cast<ui::EditBoxImplCommon*>(_editBoxImpl)->updateNativeFrame(rect);
            }
        });
        _windowResizeListener->retain();
    }
#endif
}

void EditBox::pollEvents(float dt)
{
    if (_editBoxImpl)
    {
        _editBoxImpl->pollEvents();
    }
}

void EditBox::onExit()
{
    Widget::onExit();
    if (_editBoxImpl)
    {
        // remove system edit control
        _editBoxImpl->closeKeyboard();
    }
}

void EditBox::keyboardWillShow(IMEKeyboardNotificationInfo& info)
{
    // AXLOGD("EditBox::keyboardWillShow");
    Rect rectTracked = getWorldBoundingBox();
    // some adjustment for margin between the keyboard and the edit box.
    rectTracked.origin.y -= 4;

    // if the keyboard area doesn't intersect with the tracking node area, nothing needs to be done.
    if (!rectTracked.intersectsRect(info.keyboardFrame))
    {
        return;
    }

    // assume keyboard at the bottom of screen, calculate the vertical adjustment.
    _adjustHeight = info.keyboardFrame.getMaxY() - rectTracked.getMinY();

    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->doAnimationWhenKeyboardMove(info.duration, _adjustHeight);
    }
}

void EditBox::keyboardDidShow(IMEKeyboardNotificationInfo& /*info*/) {}

void EditBox::keyboardWillHide(IMEKeyboardNotificationInfo& info)
{
    // AXLOGD("EditBox::keyboardWillHide");
    if (_editBoxImpl != nullptr)
    {
        _editBoxImpl->doAnimationWhenKeyboardMove(info.duration, -_adjustHeight);
    }
}

void EditBox::keyboardDidHide(IMEKeyboardNotificationInfo& /*info*/) {}

void EditBox::setGlobalZOrder(float globalZOrder)
{
    Widget::setGlobalZOrder(globalZOrder);
    if (_editBoxImpl)
    {
        _editBoxImpl->setGlobalZOrder(globalZOrder);
    }
}

bool EditBox::isEditing() const
{
    return _editBoxImpl && _editBoxImpl->isEditing();
}

#if AX_ENABLE_SCRIPT_BINDING
void EditBox::registerScriptEditBoxHandler(int handler)
{
    unregisterScriptEditBoxHandler();
    _scriptEditBoxHandler = handler;
}

void EditBox::unregisterScriptEditBoxHandler()
{
    if (0 != _scriptEditBoxHandler)
    {
        ScriptEngineManager::getInstance()->getScriptEngine()->removeScriptHandler(_scriptEditBoxHandler);
        _scriptEditBoxHandler = 0;
    }
}
#endif

}  // namespace ui

}  // namespace ax
