/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2012 James Chen
 Copyright (c) 2013-2015 zilongshanren
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 Copyright (c) 2019-present Simdsoft Limited.

 https://axmol.dev/

 SPDX-License-Identifier: MIT
 ****************************************************************************/

#pragma once

#include "axmol/platform/PlatformConfig.h"
#include "axmol/2d/Label.h"
#include "axmol/ui/EditBox/EditBoxImpl-common.h"
#include "axmol/ui/EditBox/EditBoxImpl.h"

namespace ax
{

namespace ui
{

class EditBox;

class AX_GUI_DLL EditBoxImplCommon : public EditBoxImpl
{
public:
    /**
     */
    EditBoxImplCommon(EditBox* pEditText);
    /**
     * @lua NA
     */
    virtual ~EditBoxImplCommon();

    bool initWithSize(const Size& size) override;

    void setFont(std::string_view fontName, int fontSize) override;
    void setFontColor(const Color32& color) override;
    void setPlaceholderFont(std::string_view fontName, int fontSize) override;
    void setPlaceholderFontColor(const Color32& color) override;
    void setInputMode(EditBox::InputMode inputMode) override;
    void setInputFlag(EditBox::InputFlag inputFlag) override;
    void setReturnType(EditBox::KeyboardReturnType returnType) override;
    void setText(std::string_view text) override;
    void setPlaceHolder(std::string_view text) override;
    void setVisible(bool visible) override;

    void setMaxLength(int maxLength) override;
    void setTextHorizontalAlignment(TextHAlignment alignment) override;
    void setTextVerticalAlignment(TextVAlignment alignment) override;

    int getMaxLength() override { return _maxLength; }
    std::string_view getText() override { return _text; }
    std::string_view getPlaceHolder() override { return _placeHolder; }

    std::string_view getFontName() override { return _fontName; }
    int getFontSize() override { return _fontSize; }
    const Color32& getFontColor() override { return _colText; }

    std::string_view getPlaceholderFontName() override { return _placeholderFontName; }
    int getPlaceholderFontSize() override { return _placeholderFontSize; }
    const Color32& getPlaceholderFontColor() override { return _colPlaceHolder; }

    EditBox::InputMode getInputMode() override { return _editBoxInputMode; }
    EditBox::InputFlag getInputFlag() override { return _editBoxInputFlag; }
    EditBox::KeyboardReturnType getReturnType() override { return _keyboardReturnType; }
    TextHAlignment getTextHorizontalAlignment() override { return _alignment; }
    TextVAlignment getTextVerticalAlignment() override { return effectiveVerticalAlignment(); }

    virtual void refreshInactiveText();

    void setContentSize(const Size& size) override;

    void setAnchorPoint(const Vec2& anchorPoint) override {}
    void setPosition(const Vec2& pos) override {}
    void setGlobalZOrder(float globalZOrder) override;

    /**
     * @lua NA
     */
    void draw(const SceneRenderState& state, const Mat4& parentTransform, uint32_t parentFlags) override;
    /**
     * @lua NA
     */
    void onEnter() override;
    void openKeyboard() override;
    void closeKeyboard() override;

    virtual void onEndEditing(std::string_view text);

    void editBoxEditingDidBegin();
    void editBoxEditingChanged(std::string_view text);
    void editBoxEditingDidEnd(std::string_view text,
                              EditBoxDelegate::EditBoxEndAction action = EditBoxDelegate::EditBoxEndAction::UNKNOWN);

    bool isEditing() override                                                      = 0;
    virtual void createNativeControl()                                             = 0;
    virtual void setNativeFont(std::string_view fontName, int fontSize)            = 0;
    virtual void setNativeFontColor(const Color32& color)                          = 0;
    virtual void setNativePlaceholderFont(std::string_view fontName, int fontSize) = 0;
    virtual void setNativePlaceholderFontColor(const Color32& color)               = 0;
    virtual void setNativeInputMode(EditBox::InputMode inputMode)                  = 0;
    virtual void setNativeInputFlag(EditBox::InputFlag inputFlag)                  = 0;
    virtual void setNativeReturnType(EditBox::KeyboardReturnType returnType)       = 0;
    virtual void setNativeTextHorizontalAlignment(ax::TextHAlignment alignment)    = 0;
    /** Optional: platforms whose native control supports it override this (default: no-op). */
    virtual void setNativeTextVerticalAlignment(ax::TextVAlignment alignment) {}
    virtual void setNativeText(std::string_view text)                              = 0;
    virtual void setNativePlaceHolder(std::string_view text)                       = 0;
    virtual void setNativeVisible(bool visible)                                    = 0;
    virtual void updateNativeFrame(const Rect& rect)                               = 0;
    virtual std::string_view getNativeDefaultFontName()                            = 0;
    virtual void nativeOpenKeyboard()                                              = 0;
    virtual void nativeCloseKeyboard()                                             = 0;
    virtual void setNativeMaxLength(int maxLength) {};

protected:
    void initInactiveLabels(const Size& size);
    void setInactiveText(std::string_view text);
    void refreshLabelAlignment();
    TextVAlignment effectiveVerticalAlignment() const
    {
        if (_vAlignmentSet)
            return _vAlignment;
        return _editBoxInputMode == EditBox::InputMode::ANY ? TextVAlignment::TOP : TextVAlignment::CENTER;
    }
    void placeInactiveLabels(const Size& size);
    Label* ensurePlaceholderLabel();
    void ensurePlaceholderIfNeeded();
    void doAnimationWhenKeyboardMove(float duration, float distance) override {};

    Label* _label;
    Label* _labelPlaceHolder;
    EditBox::InputMode _editBoxInputMode;
    EditBox::InputFlag _editBoxInputFlag;
    EditBox::KeyboardReturnType _keyboardReturnType;
    TextHAlignment _alignment;
    TextVAlignment _vAlignment = TextVAlignment::CENTER;
    bool _vAlignmentSet        = false;   // false: TOP for multi-line, CENTER otherwise (legacy behavior)

    std::string _text;
    std::string _placeHolder;

    std::string _fontName;
    std::string _placeholderFontName;

    int _fontSize;
    int _placeholderFontSize;

    Color32 _colText;
    Color32 _colPlaceHolder;

    int _maxLength;
    Size _contentSize;
    bool _editingMode;
};

}  // namespace ui

}  // namespace ax
