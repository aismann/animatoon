/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2012 James Chen
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 Copyright (c) 2019-present Simdsoft Limited.

 https://axmol.dev/

 SPDX-License-Identifier: MIT
****************************************************************************/

#pragma once

#include "axmol/base/InputDelegate.h"
#include "axmol/ui/GUIDefine.h"
#include "axmol/ui/Widget.h"
#include "axmol/ui/Scale9Sprite.h"

namespace ax
{

/**
 * @addtogroup ui
 * @{
 */
namespace ui
{

class EditBox;
class EditBoxImpl;

/**
 *@brief Editbox delegate class.
 * It's useful when you want to do some customization during Editbox input event
 *
 * @lua NA
 */
class AX_GUI_DLL EditBoxDelegate
{
public:
    /**
     * Reason for ending edit (for platforms where it is known)
     */
    enum class EditBoxEndAction
    {
        UNKNOWN,
        TAB_TO_NEXT,
        TAB_TO_PREVIOUS,
        RETURN
    };

    virtual ~EditBoxDelegate() {}

    /**
     * This method is called when an edit box gains focus after keyboard is shown.
     * @param editBox The edit box object that generated the event.
     */
    virtual void editBoxEditingDidBegin(EditBox* /*editBox*/) {}

    /**
     * This method is called when the edit box text was changed.
     * @param editBox The edit box object that generated the event.
     * @param text The new text.
     */
    virtual void editBoxTextChanged(EditBox* /*editBox*/, std::string_view /*text*/) {}

    /**
     * This method is called when the return button was pressed or the outside area of keyboard was touched.
     * @param editBox The edit box object that generated the event.
     */
    virtual void editBoxReturn(EditBox* editBox) = 0;

    /**
     * This method is called when an edit box loses focus after keyboard is hidden.
     * @param editBox The edit box object that generated the event.
     * @param type The reason why editing ended.
     */
    virtual void editBoxEditingDidEndWithAction(EditBox* /*editBox*/, EditBoxEndAction /*action*/) {}
};

/**
 * @brief Class for edit box.
 *
 * You can use this widget to gather small amounts of text from the user.
 *
 */
class AX_GUI_DLL EditBox : public Widget, public InputDelegate
{
public:
    /**
     * The popup keyboard return type.
     */
    enum class KeyboardReturnType
    {
        DEFAULT,
        DONE,
        SEND,
        SEARCH,
        GO,
        NEXT
    };

    /**
     * @brief The EditBox::InputMode defines the type of text that the user is allowed
     * to enter.
     */
    enum class InputMode
    {
        /**
         * The user is allowed to enter any text, including line breaks.
         */
        ANY,

        /**
         * The user is allowed to enter an e-mail address.
         */
        EMAIL_ADDRESS,

        /**
         * The user is allowed to enter an integer value.
         */
        NUMERIC,

        /**
         * The user is allowed to enter a phone number.
         */
        PHONE_NUMBER,

        /**
         * The user is allowed to enter a URL.
         */
        URL,

        /**
         * The user is allowed to enter a real number value.
         * This extends kEditBoxInputModeNumeric by allowing a decimal point.
         */
        DECIMAL,

        /**
         * The user is allowed to enter any text, except for line breaks.
         */
        SINGLE_LINE,
    };

    /**
     * @brief The EditBox::InputFlag defines how the input text is displayed/formatted.
     */
    enum class InputFlag
    {
        /**
         * Indicates that the text entered is confidential data that should be
         * obscured whenever possible. This implies EDIT_BOX_INPUT_FLAG_SENSITIVE.
         */
        PASSWORD,

        /**
         * Indicates that the text entered is sensitive data that the
         * implementation must never store into a dictionary or table for use
         * in predictive, auto-completing, or other accelerated input schemes.
         * A credit card number is an example of sensitive data.
         */
        SENSITIVE,

        /**
         * This flag is a hint to the implementation that during text editing,
         * the initial letter of each word should be capitalized.
         */
        INITIAL_CAPS_WORD,

        /**
         * This flag is a hint to the implementation that during text editing,
         * the initial letter of each sentence should be capitalized.
         */
        INITIAL_CAPS_SENTENCE,

        /**
         * Capitalize all characters automatically.
         */
        INITIAL_CAPS_ALL_CHARACTERS,

        /**
         * Lowercase all characters automatically.
         */
        LOWERCASE_ALL_CHARACTERS
    };

    /**
     * create a edit box with size.
     * @return An autorelease pointer of EditBox, you don't need to release it only if you retain it again.
     */
    static EditBox* create(const Size& size,
                           Scale9Sprite* normalSprite,
                           Scale9Sprite* pressedSprite  = nullptr,
                           Scale9Sprite* disabledSprite = nullptr);

    /**
     * create a edit box with size.
     * @return An autorelease pointer of EditBox, you don't need to release it only if you retain it again.
     */
    static EditBox* create(const Size& size, std::string_view normalImage, TextureResType texType);

    /**
     * create a edit box with size.
     * @return An autorelease pointer of EditBox, you don't need to release it only if you retain it again.
     */
    static EditBox* create(const Size& size,
                           std::string_view normalImage,
                           std::string_view pressedImage  = "",
                           std::string_view disabledImage = "",
                           TextureResType texType         = TextureResType::LOCAL);

    /**
     * Constructor.
     * @lua new
     */
    EditBox();

    /**
     * Destructor.
     * @lua NA
     */
    virtual ~EditBox();

    /**
     * Init edit box with specified size. This method should be invoked right after constructor.
     * @param size The size of edit box.
     * @param normal9SpriteBg  background image of edit box.
     * @param texType the resource type, the default value is TextureResType::LOCAL
     * @return Whether initialization is successfully or not.
     */
    bool initWithSizeAndBackgroundSprite(const Size& size,
                                         std::string_view normal9SpriteBg,
                                         TextureResType texType = TextureResType::LOCAL);

    /**
     * Init edit box with specified size. This method should be invoked right after constructor.
     * @param size The size of edit box.
     * @param normal9SpriteBg  background image of edit box.
     * @return Whether initialization is successfully or not.
     */
    bool initWithSizeAndBackgroundSprite(const Size& size, Scale9Sprite* normal9SpriteBg);

    /**
     * Init edit box with specified size. This method should be invoked right after constructor.
     * @param size The size of edit box.
     * @param normalSprite  normal state image of edit box.
     * @param pressedSprite  pressed state image of edit box.
     * @param disabledSprite  disabled state image of edit box.
     * @return Whether initialization is successfully or not.
     */
    bool initWithSizeAndBackgroundSprite(const Size& size,
                                         Scale9Sprite* normalSprite,
                                         Scale9Sprite* pressedSprite,
                                         Scale9Sprite* disabledSprite);

    /**
     * Init edit box with specified size. This method should be invoked right after constructor.
     * @param size The size of edit box.
     * @param normalImage  normal state texture name.
     * @param pressedImage  pressed state texture name.
     * @param disabledImage  disabled state texture name.
     * @return Whether initialization is successfully or not.
     */
    bool initWithSizeAndTexture(const Size& size,
                                std::string_view normalImage,
                                std::string_view pressedImage  = "",
                                std::string_view disabledImage = "",
                                TextureResType texType         = TextureResType::LOCAL);

    /**
     * Load textures for edit box.
     *
     * @param normal    normal state texture name.
     * @param pressed    pressed state texture name.
     * @param disabled    disabled state texture name.
     * @param texType    @see `TextureResType`
     */
    void loadTextures(std::string_view normal,
                      std::string_view pressed,
                      std::string_view disabled = "",
                      TextureResType texType    = TextureResType::LOCAL);

    /**
     * Load normal state texture for edit box.
     *
     * @param normal    normal state texture.
     * @param texType    @see `TextureResType`
     */
    void loadTextureNormal(std::string_view normal, TextureResType texType = TextureResType::LOCAL);

    /**
     * Load pressed state texture for edit box.
     *
     * @param pressed    pressed state texture.
     * @param texType    @see `TextureResType`
     */
    void loadTexturePressed(std::string_view pressed, TextureResType texType = TextureResType::LOCAL);

    /**
     * Load disabled state texture for edit box.
     *
     * @param disabled    dark state texture.
     * @param texType    @see `TextureResType`
     */
    void loadTextureDisabled(std::string_view disabled, TextureResType texType = TextureResType::LOCAL);

    /**
     * Sets capInsets for edit box.
     *
     * @param capInsets    capInset in Rect.
     */
    void setCapInsets(const Rect& capInsets);

    /**
     * Sets capInsets for edit box, only the normal state scale9 renderer will be affected.
     *
     * @param capInsets    capInsets in Rect.
     */
    void setCapInsetsNormalRenderer(const Rect& capInsets);

    /**
     * Return the capInsets of normal state scale9sprite.
     * @return The normal scale9 renderer capInsets.
     */
    const Rect& getCapInsetsNormalRenderer() const;

    /**
     * Sets capInsets for edit box, only the pressed state scale9 renderer will be affected.
     *
     * @param capInsets    capInsets in Rect
     */
    void setCapInsetsPressedRenderer(const Rect& capInsets);

    /**
     * Return the capInsets of pressed state scale9sprite.
     * @return The pressed scale9 renderer capInsets.
     */
    const Rect& getCapInsetsPressedRenderer() const;

    /**
     * Sets capInsets for edit box, only the disabled state scale9 renderer will be affected.
     *
     * @param capInsets  capInsets in Rect.
     */
    void setCapInsetsDisabledRenderer(const Rect& capInsets);

    /**
     * Return the capInsets of disabled state scale9sprite.
     * @return The disabled scale9 renderer capInsets.
     */
    const Rect& getCapInsetsDisabledRenderer() const;

    /**
     * Gets/Sets the delegate for edit box.
     * @lua NA
     */
    void setDelegate(EditBoxDelegate* delegate);

    /**
     * @lua NA
     */
    EditBoxDelegate* getDelegate();

#if AX_ENABLE_SCRIPT_BINDING
    /**
     * Registers a script function that will be called for EditBox events.
     *
     * This handler will be removed automatically after onExit() called.
     * @code
     * -- lua sample
     * local function editboxEventHandler(eventType)
     *     if eventType == "began" then
     *         -- triggered when an edit box gains focus after keyboard is shown
     *     elseif eventType == "ended" then
     *         -- triggered when an edit box loses focus after keyboard is hidden.
     *     elseif eventType == "changed" then
     *         -- triggered when the edit box text was changed.
     *     elseif eventType == "return" then
     *         -- triggered when the return button was pressed or the outside area of keyboard was touched.
     *     end
     * end
     *
     * local editbox = EditBox:create(Size(...), Scale9Sprite:create(...))
     * editbox = registerScriptEditBoxHandler(editboxEventHandler)
     * @endcode
     *
     * @param handler A number that indicates a lua function.
     * @lua NA
     */
    void registerScriptEditBoxHandler(int handler);

    /**
     * Unregisters a script function that will be called for EditBox events.
     * @lua NA
     */
    void unregisterScriptEditBoxHandler();
    /**
     * get a script Handler
     * @lua NA
     */
    int getScriptEditBoxHandler() { return _scriptEditBoxHandler; }

#endif  // #if AX_ENABLE_SCRIPT_BINDING

    /**
     * Set the text entered in the edit box.
     * @param text The given text.
     */
    void setText(std::string_view text);

    /**
     * Get the text entered in the edit box.
     * @return The text entered in the edit box.
     */
    std::string_view getText() const;

    /**
     * Set the font. Only system font is allowed.
     * @param fontName The font name.
     * @param fontSize The font size.
     */
    void setFont(std::string_view fontName, int fontSize);

    /**
     * Set the font name. Only system font is allowed.
     * @param fontName The font name.
     */
    void setFontName(std::string_view fontName);

    /**
     * Get the font name.
     * @return The font name.
     */
    std::string_view getFontName() const;

    /**
     * Set the font size.
     * @param fontSize The font size.
     */
    void setFontSize(int fontSize);

    /**
     * Get the font size.
     * @return The font size.
     */
    int getFontSize() const;

    /**
     * Set the font color of the widget's text.
     */
    void setFontColor(const Color32& color);

    /**
     * Get the font color of the widget's text.
     */
    const Color32& getFontColor() const;

    /**
     * Set the placeholder's font. Only system font is allowed.
     * @param fontName The font name.
     * @param fontSize The font size.
     */
    void setPlaceholderFont(std::string_view fontName, int fontSize);

    /**
     * Set the placeholder's font name. only system font is allowed.
     * @param fontName The font name.
     */
    void setPlaceholderFontName(std::string_view fontName);

    /**
     * Get the placeholder's font name. only system font is allowed.
     * @return The font name.
     */
    std::string_view getPlaceholderFontName() const;

    /**
     * Set the placeholder's font size.
     * @param fontSize The font size.
     */
    void setPlaceholderFontSize(int fontSize);

    /**
     * Get the placeholder's font size.
     * @return The font size.
     */
    int getPlaceholderFontSize() const;

    /**
     * Set the font color of the placeholder text when the edit box is empty.
     */
    void setPlaceholderFontColor(const Color32& color);

    /**
     * Get the font color of the placeholder text when the edit box is empty.
     */
    const Color32& getPlaceholderFontColor() const;

    /**
     * Set a text in the edit box that acts as a placeholder when an
     * edit box is empty.
     * @param text The given text.
     */
    void setPlaceHolder(std::string_view text);

    /**
     * Get a text in the edit box that acts as a placeholder when an
     * edit box is empty.
     */
    std::string_view getPlaceHolder() const;

    /**
     * Set the input mode of the edit box.
     * @param inputMode One of the EditBox::InputMode constants.
     */
    void setInputMode(InputMode inputMode);

    /**
     * Get the input mode of the edit box.
     * @return One of the EditBox::InputMode constants.
     */
    InputMode getInputMode() const;

    /**
     * Sets the maximum input length of the edit box.
     * Setting this value enables multiline input mode by default.
     * Available on Android, iOS and Windows Phone.
     *
     * @param maxLength The maximum length.
     */
    void setMaxLength(int maxLength);

    /**
     * Gets the maximum input length of the edit box.
     *
     * @return Maximum input length.
     */
    int getMaxLength();

    /**
     * Set the input flags that are to be applied to the edit box.
     * @param inputFlag One of the EditBox::InputFlag constants.
     */
    void setInputFlag(InputFlag inputFlag);

    /**
     * Get the input flags that are to be applied to the edit box.
     * @return One of the EditBox::InputFlag constants.
     */
    InputFlag getInputFlag() const;

    /**
     * Set the return type that are to be applied to the edit box.
     * @param returnType One of the EditBox::KeyboardReturnType constants.
     */
    void setReturnType(KeyboardReturnType returnType);

    /**
     * Get the return type that are to be applied to the edit box.
     * @return One of the EditBox::KeyboardReturnType constants.
     */
    KeyboardReturnType getReturnType() const;

    /**
     * Set the text horizontal alignment.
     */
    void setTextHorizontalAlignment(TextHAlignment alignment);

    /**
     * Get the text horizontal alignment.
     */
    TextHAlignment getTextHorizontalAlignment() const;

    /**
     * Set the text vertical alignment (TOP, CENTER or BOTTOM).
     *
     * If never called, the default behavior is kept: TOP for InputMode::ANY (multi-line), CENTER otherwise.
     * Applies to the placeholder and to the text shown while the edit box is not being edited. The native
     * text control is updated on Android and iOS (single-line field); other platforms keep their
     * native vertical placement while editing.
     */
    void setTextVerticalAlignment(TextVAlignment alignment);

    /**
     * Get the text vertical alignment.
     */
    TextVAlignment getTextVerticalAlignment() const;

    /* override functions */
    void setPosition(const Vec2& pos) override;
    void setVisible(bool visible) override;
    void setContentSize(const Size& size) override;
    void setAnchorPoint(const Vec2& anchorPoint) override;

    /**
     * Returns the "class name" of widget.
     */
    std::string getDescription() const override;

    /**
     * @lua NA
     */
    void draw(const SceneRenderState& state, const Mat4& parentTransform, uint32_t parentFlags) override;
    /**
     * @lua NA
     */
    void onEnter() override;
    /**
     * @lua NA
     */
    void onExit() override;
    /**
     * @lua NA
     */
    void keyboardWillShow(IMEKeyboardNotificationInfo& info) override;
    /**
     * @lua NA
     */
    void keyboardDidShow(IMEKeyboardNotificationInfo& info) override;
    /**
     * @lua NA
     */
    void keyboardWillHide(IMEKeyboardNotificationInfo& info) override;
    /**
     * @lua NA
     */
    void keyboardDidHide(IMEKeyboardNotificationInfo& info) override;

    void setGlobalZOrder(float globalZOrder) override;

    void openKeyboard() const;
    void closeKeyboard() const;

    /**
     * Get the editing state of the EditBox
     * @return true if editing
     */
    bool isEditing() const;

protected:
    void releaseUpEvent() override;

    void initRenderNode() override;
    void onPressStateChangedToNormal() override;
    void onPressStateChangedToPressed() override;
    void onPressStateChangedToDisabled() override;
    void onSizeChanged() override;

    void loadTextureNormal(SpriteFrame* normalSpriteFrame);
    void setupNormalTexture(bool textureLoaded);
    void loadTexturePressed(SpriteFrame* pressedSpriteFrame);
    void setupPressedTexture(bool textureLoaded);
    void loadTextureDisabled(SpriteFrame* disabledSpriteFrame);
    void setupDisabledTexture(bool textureLoaded);

    void normalTextureScaleChangedWithSize();
    void pressedTextureScaleChangedWithSize();
    void disabledTextureScaleChangedWithSize();

    void updateLayout() override;

protected:
    void pollEvents(float dt);

    Scale9Sprite* _normalRenderer   = nullptr;
    Scale9Sprite* _pressedRenderer  = nullptr;
    Scale9Sprite* _disabledRenderer = nullptr;

    Rect _capInsetsNormal;
    Rect _capInsetsPressed;
    Rect _capInsetsDisabled;

    Size _normalTextureSize;
    Size _pressedTextureSize;
    Size _disabledTextureSize;

    bool _normalTextureLoaded       = false;
    bool _pressedTextureLoaded      = false;
    bool _disabledTextureLoaded     = false;
    bool _normalTextureAdaptDirty   = true;
    bool _pressedTextureAdaptDirty  = true;
    bool _disabledTextureAdaptDirty = true;

    std::string _normalFileName;
    std::string _pressedFileName;
    std::string _disabledFileName;
    TextureResType _normalTexType   = TextureResType::LOCAL;
    TextureResType _pressedTexType  = TextureResType::LOCAL;
    TextureResType _disabledTexType = TextureResType::LOCAL;

    EditBoxImpl* _editBoxImpl  = nullptr;
    EditBoxDelegate* _delegate = nullptr;

    CustomEventListener* _windowResizeListener{nullptr};

    float _adjustHeight = 0.f;
#if AX_ENABLE_SCRIPT_BINDING
    int _scriptEditBoxHandler = 0;
#endif
};
}  // namespace ui

// end of ui group
/// @}
}  // namespace ax
