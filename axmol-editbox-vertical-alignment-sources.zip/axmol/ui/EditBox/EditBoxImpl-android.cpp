/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2012 James Chen
 Copyright (c) 2013-2015 zilongshanren
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 Copyright (c) 2019-present Simdsoft Limited.

 https://axmol.dev/

 SPDX-License-Identifier: MIT
 ****************************************************************************/

#include "axmol/ui/EditBox/EditBoxImpl-android.h"

#if (AX_TARGET_PLATFORM == AX_PLATFORM_ANDROID)

#    include "axmol/ui/EditBox/EditBox.h"
#    include <cmath>
#    include <jni.h>
#    include "axmol/platform/android/jni/JniHelper.h"
#    include "axmol/2d/Label.h"
#    include "axmol/base/text_utils.h"
#    include "axmol/math/Vec2.h"
#    include "axmol/ui/UIHelper.h"
#    include "axmol/base/Director.h"
#    include "yasio/tlx/string_view.hpp"

namespace ax
{

static const char* editBoxClassName = "dev.axmol.lib.EditBoxHelper";

namespace ui
{

#    define LOGD(...) __android_log_print(ANDROID_LOG_ERROR, "", __VA_ARGS__)
static void editBoxEditingDidBegin(int index);
static void editBoxEditingDidChanged(int index, std::string_view text);
static void editBoxEditingDidEnd(int index, std::string_view text, int action);

static std::unordered_map<int, EditBoxImplAndroid*> s_allEditBoxes;

EditBoxImpl* __createSystemEditBox(EditBox* editBox)
{
    return new EditBoxImplAndroid(editBox);
}

EditBoxImplAndroid::EditBoxImplAndroid(EditBox* pEditText) : EditBoxImplCommon(pEditText), _editBoxIndex(-1) {}

EditBoxImplAndroid::~EditBoxImplAndroid()
{
    s_allEditBoxes.erase(_editBoxIndex);
    JniHelper::callStaticVoidMethod(editBoxClassName, "removeEditBox", _editBoxIndex);
}

void EditBoxImplAndroid::createNativeControl()
{
    auto renderView = ax::Director::getInstance()->getRenderView();
    _editBoxIndex =
        JniHelper::callStaticIntMethod(editBoxClassName, "createEditBox", 0, 0, 1, 1, (float)renderView->getScaleX());
    s_allEditBoxes[_editBoxIndex] = this;
}

void EditBoxImplAndroid::setNativeFont(std::string_view fontName, int fontSize)
{
    auto director   = ax::Director::getInstance();
    auto renderView = director->getRenderView();
    JniHelper::callStaticVoidMethod(editBoxClassName, "setFont", _editBoxIndex, fontName,
                                    (float)fontSize * renderView->getScaleX());
}

void EditBoxImplAndroid::setNativeFontColor(const Color32& color)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setFontColor", _editBoxIndex, (int)color.r, (int)color.g,
                                    (int)color.b, (int)color.a);
}

void EditBoxImplAndroid::setNativePlaceholderFont(std::string_view /*fontName*/, int /*fontSize*/)
{
    AXLOGD("Warning! You can't change Android Hint fontName and fontSize");
}

void EditBoxImplAndroid::setNativePlaceholderFontColor(const Color32& color)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setPlaceHolderTextColor", _editBoxIndex, (int)color.r,
                                    (int)color.g, (int)color.b, (int)color.a);
}

void EditBoxImplAndroid::setNativeInputMode(EditBox::InputMode inputMode)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setInputMode", _editBoxIndex, static_cast<int>(inputMode));
}

void EditBoxImplAndroid::setNativeMaxLength(int maxLength)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setMaxLength", _editBoxIndex, maxLength);
}

void EditBoxImplAndroid::setNativeInputFlag(EditBox::InputFlag inputFlag)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setInputFlag", _editBoxIndex, static_cast<int>(inputFlag));
}

void EditBoxImplAndroid::setNativeReturnType(EditBox::KeyboardReturnType returnType)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setReturnType", _editBoxIndex, static_cast<int>(returnType));
}

void EditBoxImplAndroid::setNativeTextHorizontalAlignment(ax::TextHAlignment alignment)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setTextHorizontalAlignment", _editBoxIndex,
                                    static_cast<int>(alignment));
}

void EditBoxImplAndroid::setNativeTextVerticalAlignment(ax::TextVAlignment alignment)
{
    // TextVAlignment: TOP = 0, CENTER = 1, BOTTOM = 2 (matches AxmolEditBox.kTextVerticalAlignment*)
    JniHelper::callStaticVoidMethod(editBoxClassName, "setTextVerticalAlignment", _editBoxIndex,
                                    static_cast<int>(alignment));
}

bool EditBoxImplAndroid::isEditing()
{
    return _editingMode;
}

void EditBoxImplAndroid::setNativeText(std::string_view text)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setText", _editBoxIndex, text);
}

void EditBoxImplAndroid::setNativePlaceHolder(std::string_view text)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setPlaceHolderText", _editBoxIndex, text);
}

void EditBoxImplAndroid::setNativeVisible(bool visible)
{  // don't need to be implemented on android platform.
    JniHelper::callStaticVoidMethod(editBoxClassName, "setVisible", _editBoxIndex, visible);
}

void EditBoxImplAndroid::updateNativeFrame(const Rect& rect)
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "setEditBoxViewRect", _editBoxIndex,
                                    (int)std::lround(rect.origin.x), (int)std::lround(rect.origin.y),
                                    (int)std::lround(rect.size.width), (int)std::lround(rect.size.height));
}

void EditBoxImplAndroid::nativeOpenKeyboard()
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "openKeyboard", _editBoxIndex);
}

void EditBoxImplAndroid::nativeCloseKeyboard()
{
    JniHelper::callStaticVoidMethod(editBoxClassName, "closeKeyboard", _editBoxIndex);
}

void editBoxEditingDidBegin(int index)
{
    auto it = s_allEditBoxes.find(index);
    if (it != s_allEditBoxes.end())
    {
        s_allEditBoxes[index]->editBoxEditingDidBegin();
    }
}
void editBoxEditingDidChanged(int index, std::string_view text)
{
    auto it = s_allEditBoxes.find(index);
    if (it != s_allEditBoxes.end())
    {
        s_allEditBoxes[index]->editBoxEditingChanged(text);
    }
}

void editBoxEditingDidEnd(int index, std::string_view text, int action)
{
    auto it = s_allEditBoxes.find(index);
    if (it != s_allEditBoxes.end())
    {
        s_allEditBoxes[index]->editBoxEditingDidEnd(text,
                                                    static_cast<ax::ui::EditBoxDelegate::EditBoxEndAction>(action));
    }
}

std::string_view EditBoxImplAndroid::getNativeDefaultFontName()
{
    return "sans-serif"sv;
}

}  // namespace ui

}  // namespace ax

extern "C" {
JNIEXPORT void JNICALL Java_dev_axmol_lib_EditBoxHelper_nativeEditBoxEditingDidBegin(JNIEnv*, jclass, jint index)
{
    ax::ui::editBoxEditingDidBegin(index);
}

JNIEXPORT void JNICALL Java_dev_axmol_lib_EditBoxHelper_nativeEditBoxEditingChanged(JNIEnv* env,
                                                                                    jclass,
                                                                                    jint index,
                                                                                    jstring text)
{
    std::string textString = ax::text_utils::getStringUTFCharsJNI(env, text);
    ax::ui::editBoxEditingDidChanged(index, textString);
}

JNIEXPORT void JNICALL
Java_dev_axmol_lib_EditBoxHelper_nativeEditBoxEditingDidEnd(JNIEnv* env, jclass, jint index, jstring text, jint action)
{
    std::string textString = ax::text_utils::getStringUTFCharsJNI(env, text);
    ax::ui::editBoxEditingDidEnd(index, textString, action);
}
}

#    undef LOGD

#endif /* #if (AX_TARGET_PLATFORM == AX_PLATFORM_ANDROID) */
